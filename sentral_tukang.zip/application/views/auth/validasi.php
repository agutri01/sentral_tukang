<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>UNICO SENTRAL DISTRIBUSI | LOGIN</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="shortcut icon" href="<?= theme() ?>favicon.ico" />
    <link rel="stylesheet" href="<?= theme() ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= theme() ?>bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= theme() ?>bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?= theme() ?>dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?= theme() ?>plugins/iCheck/square/blue.css">
    <link rel="stylesheet" href="<?= theme() ?>bower_components/source-sans/source-sans-pro.css">
</head>

<body class="hold-transition login-page" >
    <div class="login-box" style="margin-top: 50px" style="font-size: 12pt;">
        
        <div class="form-group has-feedback">
        <div class="modal-content">
            <div class="modal-body">
            <center> <h4> Ether Your email/password is incorrect please try again
            </center>
                <a href="<?= site_url('') ?>" class="btn btn-danger btn-block btn-flat"></i> Oke</a>
            </div>
        </div>
    </div>     
        </div>
</body>
</html>